import React from 'react';
import { useParams } from 'react-router-dom';

const CategoryPage = () => {
  const { categoryId } = useParams();

  // Выполните необходимую логику для выбранной категории

  return (
    <div>
      <h1>Category: {categoryId}</h1>
      {/* Отобразите соответствующие новости или выполните другие действия */}
    </div>
  );
};

export default CategoryPage;
